//
//  RotationViewController.h
//  GesturesDemo
//
//  Created by Gabriel Theodoropoulos on 8/22/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RotationViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *testView;

@end
